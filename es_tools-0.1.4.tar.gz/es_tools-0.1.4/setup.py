# -*- coding: utf-8 -*-
#
# setup.py
#
# Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""
es_tool - Elasticsearch backup/restore tool
"""

import io
import os
import re
from setuptools import setup


def read(*names, **kwargs):
    with io.open(
        os.path.join(os.path.dirname(__file__), *names),
        encoding=kwargs.get("encoding", "utf8")
    ) as fp:
        return fp.read()


def find_version(*file_paths):
    version_file = read(*file_paths)
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]",
                              version_file, re.M)
    if version_match:
        return version_match.group(1)
    raise RuntimeError("Unable to find version string.")


setup(
    name='es_tools',
    version=find_version("es_tools", "__init__.py"),
    packages=['es_tools'],
    url='',
    license='Apache 2.0',
    author='koiker',
    author_email='koiker@amazon.com',
    description='Elasticsearch backup and restore for kibana dashboards',
    entry_points={
        'console_scripts': [
            'es-export = es_tools.es_export:cli_export',
            'es-import = es_tools.es_import:cli_import'
        ]

    },
    install_requires=[
        'boto3>=1.3.1',
        'click>=6.6',
        'elasticsearch>=2.3.0,<3.0.0',
        'requests_aws4auth>=0.9'
    ]

)
